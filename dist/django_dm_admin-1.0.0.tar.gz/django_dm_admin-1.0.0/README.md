# 🚀 Django Dynamic Admin

[![PyPI version](https://badge.fury.io/py/django-dm-admin.svg)](https://badge.fury.io/py/django-dm-admin)
[![License: MIT](https://img.shields.io/badge/License-MIT-yellow.svg)](https://opensource.org/licenses/MIT)
[![Python](https://img.shields.io/badge/Python-3.8+-blue.svg)](https://www.python.org/)
[![Django](https://img.shields.io/badge/Django-3.2+-green.svg)](https://www.djangoproject.com/)

一个通用的 Django Admin 后台管理组件，用于动态展示和管理 REST API 数据。无需编写模型，直接接入第三方 API！

## ✨ 特性

- 🔄 **零模型接入** - 无需创建 Django 模型，直接展示 API 数据
- 📦 **Redis 缓存** - 内置缓存机制，减少 API 调用
- 🔍 **高级搜索** - 支持多字段组合搜索
- 📊 **智能排序** - 支持多字段任意排序
- 📄 **文件处理** - 支持 PDF 等文件在线预览/下载
- 📝 **操作日志** - 完整记录用户操作
- 🎨 **UI 扩展** - 支持 SimpleUI、Ajax 等

## 📺 演示

![Demo](https://via.placeholder.com/800x400?text=Django+API+Admin+Demo)

## 🛠️ 安装

```bash
pip install django-dm-admin
```

或从源码安装：

```bash
pip install -e .
```

## 🚢 快速开始

### 1. 创建模型

```python
# models.py
from django.db import models
from django_api_admin.models import APIModel


class MyAPIData(APIModel):
    class Meta:
        verbose_name = '我的API数据'
        cache = 'my_api_data_'
        black_fields = ['id']
    
    def urls(self):
        return '/api/my-data/'
```

### 2. 创建 Admin

```python
# admin.py
from django.contrib import admin
from django_api_admin.admin import APIAdmin
from .models import MyAPIData


@admin.register(MyAPIData)
class MyAPIAdmin(APIAdmin):
    list_per_page = 10000
    paras_list = ['q', 'o', 'dt', 'p']
```

### 3. 完成！

现在访问 Admin 页面，API 数据会自动展示！

## 📚 文档

- [完整文档](https://github.com/yourusername/django-api-admin/wiki)
- [API 参考](https://github.com/yourusername/django-api-admin/wiki/API-Reference)
- [示例代码](./example/)

## ⚙️ 配置

| 配置项 | 说明 | 默认值 |
|--------|------|--------|
| `list_per_page` | 每页数量 | 20000 |
| `paras_list` | API 参数列表 | `['q', 'o', 'dt', 'p']` |
| `black_fields` | 排除字段 | `[]` |
| `cache_config` | Redis 配置 | 内置配置 |

## 🤝 贡献

欢迎提交 Issue 和 Pull Request！

1. Fork 本项目
2. 创建分支 (`git checkout -b feature/amazing`)
3. 提交更改 (`git commit -m 'Add amazing feature'`)
4. 推送分支 (`git push origin feature/amazing`)
5. 创建 Pull Request

## 📝 License

MIT License - 查看 [LICENSE](LICENSE) 了解更多

## 🙏 致谢

- [Django](https://www.djangoproject.com/)
- [SimpleUI](https://github.com/newpanjing/simpleui)
- [Redis](https://redis.io/)

---

如果这个项目对你有帮助，请 ⭐ Star 支持！
